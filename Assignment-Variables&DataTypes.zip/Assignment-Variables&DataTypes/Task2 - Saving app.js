let SamWantToSave = 10000;
let SamAlreadySave = 7500;
//computation
let TotalAmountNeeded = (SamAlreadySave / SamWantToSave) * 100;
let TotaPercentNeeded = 100 - TotalAmountNeeded;
//Output
console.log(`Thank you for your discipline and hardwork, Sam! You are now ${TotaPercentNeeded}% away from your goal of saving ₱10,000`);
