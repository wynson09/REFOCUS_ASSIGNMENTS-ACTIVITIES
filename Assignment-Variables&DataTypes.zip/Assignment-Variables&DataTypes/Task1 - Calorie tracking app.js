let SamCyclingPerDay = 0.5;
let numTimesSamCycling = 15;
let caloriesPerHalfanHour = 225;

//computation
let TotalCaloriesLose = numTimesSamCycling * caloriesPerHalfanHour;

console.log(`Great work, Sam! after ${SamCyclingPerDay} hour/s of cycling everyday for 15days, you may lose a total of ${TotalCaloriesLose} calories`);