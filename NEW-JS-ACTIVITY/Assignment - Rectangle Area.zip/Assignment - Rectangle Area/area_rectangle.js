var width = 16;
var length = 20;
//Calculate the area of a rectangle
let area = width * length;

console.log(`Width: ${width}`);
console.log(`Length: ${length}`);
console.log(`Area: ${area}`);