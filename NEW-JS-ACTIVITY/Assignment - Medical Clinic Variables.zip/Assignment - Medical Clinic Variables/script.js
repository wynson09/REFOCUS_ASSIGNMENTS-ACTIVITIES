let firstName = 'Wynson Carl';
let lastName = 'Nacalaban';

console.log(`Hello, ${firstName} ${lastName}! How can we help you today?`);