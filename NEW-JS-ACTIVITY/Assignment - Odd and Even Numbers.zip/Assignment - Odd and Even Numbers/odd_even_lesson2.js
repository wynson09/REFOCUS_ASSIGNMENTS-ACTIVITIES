for (let i = 1; i <= 10; i++){
    (i % 2 == 0) ? console.log(`${i} is even`):console.log(`${i} is odd`);
}