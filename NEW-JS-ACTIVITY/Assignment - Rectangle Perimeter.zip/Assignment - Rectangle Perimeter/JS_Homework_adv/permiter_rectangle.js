const width = 16;
const length = 20;
//Calculate the Perimeter
let p = 2 * (length + width);

console.log(`Width: ${width}`);
console.log(`Length: ${length}`);
console.log(`Perimeter: ${p}`);